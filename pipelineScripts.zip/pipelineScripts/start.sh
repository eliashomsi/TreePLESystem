#!/bin/bash
sudo ip route add 192.168.56.50/32 dev lo
sudo cp /home/ecse321/workspace/TreePLE/TreePLE/TreePLE-Spring/build/libs/eventregistration-0.0.1-SNAPSHOT.war /opt/tomcat/webapps/ROOT.war
sudo systemctl stop tomcat
sudo bash /home/ecse321/catalina.sh stop
sudo bash /home/ecse321/catalina.sh start
sudo npm run build --prefix /home/ecse321/workspace/TreePLE/TreePLE/TreePLE-Web/
sudo cp -rf /home/ecse321/workspace/TreePLE/TreePLE/TreePLE-Web/dist/* /var/www/html/
sudo chown apache:apache -R /var/www/
sudo systemctl restart httpd


